from PySide6 import QtCore, QtGui, QtWidgets
from panels.builder_panel import BuilderPanel
from panels.file_tools import FileToolsPanel
from panels.google_tools import GoogleToolsPanel
from helpers import extract_google_id

APP_VERSION = "v1.0.0"

class OpsWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"Unified Operations Shell {APP_VERSION}")
        self._builder = None
        self._filetools = None
        self._googtools = None

    def _on_nav(self, btn):
        label = btn.text()
        if label == "Builder":
            if self._builder is None:
                self._builder = BuilderPanel()
        elif label == "File Tools":
            if self._filetools is None:
                self._filetools = FileToolsPanel()
        elif label == "Google Tools":
            if self._googtools is None:
                self._googtools = GoogleToolsPanel()

if __name__ == "__main__":
    app = QtWidgets.QApplication([])
    win = OpsWindow()
    win.show()
    app.exec()
