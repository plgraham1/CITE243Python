from pathlib import Path
from PySide6 import QtWidgets
from helpers import extract_google_id
import ezsheets

class GoogleToolsPanel(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(8)

        title = QtWidgets.QLabel("Google Sheets Automation Tools")
        title.setStyleSheet("font-size: 20px; font-weight: bold;")
        layout.addWidget(title)

        self.log = QtWidgets.QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)

        btn_form = QtWidgets.QPushButton("Download Google Form Data")
        btn_convert = QtWidgets.QPushButton("Convert Spreadsheet Formats")
        btn_check = QtWidgets.QPushButton("Find Spreadsheet Mistakes")

        layout.addWidget(btn_form)
        layout.addWidget(btn_convert)
        layout.addWidget(btn_check)

        btn_form.clicked.connect(self.download_form_data)
        btn_convert.clicked.connect(self.convert_spreadsheet)
        btn_check.clicked.connect(self.find_mistakes)

    def download_form_data(self):
        self._run_sheet_task("form")

    def convert_spreadsheet(self):
        self._run_sheet_task("convert")

    def find_mistakes(self):
        self._run_sheet_task("check")

    def _run_sheet_task(self, mode):
        url, ok = QtWidgets.QInputDialog.getText(self, "Google Sheet Link", "Paste your Google Sheet share link or ID:")
        if not ok or not url.strip():
            self.log.append("Cancelled.")
            return
        sheet_id = extract_google_id(url)
        ss = ezsheets.Spreadsheet(sheet_id)
        sheet = ss[0]
        if mode == "form":
            rows = sheet.getRows()
            emails = [r[1] for r in rows[1:] if len(r) > 1 and r[1]]
            self.log.append(f"Found {len(emails)} email addresses.")
        elif mode == "convert":
            base = Path.home() / "Documents" / "Google_Exports"
            base.mkdir(parents=True, exist_ok=True)
            ss.downloadAsExcel(str(base / f"{ss.title}.xlsx"))
            ss.downloadAsODS(str(base / f"{ss.title}.ods"))
            ss.downloadAsCSV(str(base / f"{ss.title}.csv"))
            self.log.append(f"Saved exports to {base}")
        elif mode == "check":
            for rowNum in range(2, sheet.rowCount + 1):
                row = sheet.getRow(rowNum)
                if not all(row[:3]): continue
                try:
                    if int(row[0]) * int(row[1]) != int(row[2]):
                        self.log.append(f"Error found in row {rowNum}: {row}")
                        return
                except ValueError:
                    continue
            self.log.append("No errors found.")
