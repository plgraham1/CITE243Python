import re

def extract_google_id(url_or_id: str) -> str:
    match = re.search(r"/d/([A-Za-z0-9_-]+)", url_or_id or "")
    return match.group(1) if match else (url_or_id or "").strip()
